/**
 * File: GraphicExample.cpp
 * ---------------------------
 * This program illustrates the use of graphics
 * using the GWindow class.
 */

#include "gwindow.h"

int main() {
  GWindow window;

  /* Set the window title */
  window.setWindowTitle("Diamond");

  /* Get the width and height of  */
  double width = window.getWidth();
  double height = window.getHeight();

  /* Draw line connecting the midpoints of the edges. */
  window.drawLine(0, height / 2, width / 2, 0);
  window.drawLine(width / 2, 0, width, height / 2);
  window.drawLine(width, height / 2, width / 2, height);
  window.drawLine(width / 2, height, 0, height / 2);

  return 0;
}
