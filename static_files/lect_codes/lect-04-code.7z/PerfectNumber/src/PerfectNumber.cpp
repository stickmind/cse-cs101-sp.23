/**
 * File: PerfectNumber.cpp
 * -----------------------
 * This program finds all the perfect numbers between two limits
 * entered by the user.
 * A perfect number is a non-zero positive number whose sum
 * of its proper divisors is equal to itself.
 */

#include <iostream>
#include "console.h"
#include "error.h"
#include "simpio.h"

/**
 * Function: sumOfDivisorsOf
 * Usage: int p = sumOfDivisorsOf(n);
 * ----------------------------------
 * This function takes one argument `n` and calculates the sum of
 * all proper divisors of `n` excluding itself.
 * To find divisors a loop iterates over all numbers from 1 to n-1,
 * testing for a zero remainder from the division.
 */

int sumOfDivisorsOf(int n) {
    int total = 0;
    for (int divisor = 1; divisor < n; divisor++) {
        if (n % divisor == 0) {
            total += divisor;
        }
    }
    return total;
}

/**
 * Function: isPerfect
 * Usage: bool flag = isPerfect(n);
 * --------------------------------
 * This function takes one argument `n` and returns a boolean
 * (true/false) value indicating whether or not `n` is perfect.
 */
bool isPerfect(int n) {
    return (n != 0) && (n == sumOfDivisorsOf(n));
}

/* Main program */

int main() {
    int lower = getInteger("Enter lower limit: ");
    int upper = getInteger("Enter upper limit: ");

    for (int i = lower; i <= upper; i++) {
        if (isPerfect(i)) {
            std::cout << i << std::endl;
        }
    }

    return 0;
}
