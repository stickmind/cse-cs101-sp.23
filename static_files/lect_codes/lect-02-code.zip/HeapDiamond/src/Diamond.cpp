/**
 * File: GraphicExample.cpp
 * ---------------------------
 * This program illustrates the use of graphics
 * using the GWindow class.
 */

#include "gobjects.h"
#include "gwindow.h"

int main() {
  GWindow window;

  /* Set the window title */
  window.setWindowTitle("Diamond");

  /* Get the width and height of  */
  double width = window.getWidth();
  double height = window.getHeight();

  /* Draw line connecting the midpoints of the edges. */
  GLine* line = new GLine(0, height / 2, width / 2, 0);
  window.add(line);
  line = new GLine(width / 2, 0, width, height / 2);
  window.add(line);
  line = new GLine(width, height / 2, width / 2, height);
  window.add(line);
  line = new GLine(width / 2, height, 0, height / 2);
  window.add(line);

  return 0;
}
