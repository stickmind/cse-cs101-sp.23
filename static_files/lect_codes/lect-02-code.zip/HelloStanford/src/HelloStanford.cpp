/**
 * File: HelloStanford.cpp
 * -----------------------
 * This file is adapted from the example on page 1 of Kernighan
 * and Ritchie's book The C Programming Language.
 */

#include <iostream>
#include "console.h" // for SimpleCxxLib

int main() {
    std::cout << "Hello, Stanford!" << std::endl;
    return 0;
}
