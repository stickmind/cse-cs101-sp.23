/**
 * File: Acronym.cpp
 * -----------------
 * This program generates and displays acronyms.
 */

#include <cctype>
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h"
using namespace std;

/* Function prototypes */

string acronym(string str);

/* Main program */

int main() {
   cout << "Program to generate acronyms" << endl;
   while (true) {
      string str = getLine("Enter string: ");
      if (str == "") break;
      cout << "The acronym is \"" << acronym(str) << "\"" << endl;
   }
   return 0;
}

/**
 * Function: acronym
 * Usage: string acronym = acronym(str);
 * -------------------------------------
 * Generates the acronym for the given string.
 */

string acronym(string str) {
   string result = "";
   bool inWord = false;
   int nc = str.length();
   for (int i = 0; i < nc; i++) {
      char ch = str[i];
      if (inWord) {
         if (!isalpha(ch)) inWord = false;
      } else {
         if (isalpha(ch)) {
            result += ch;
            inWord = true;
         }
      }
   }
   return result;
}
