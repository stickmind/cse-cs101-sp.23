/**
 * File: DrawStar.cpp
 * ------------------
 * This program draws a series of increasingly larger stars on the canvas.
 */

#include <cmath>
#include "gobjects.h"
#include "gwindow.h"

/* Constant controlling the radius of the star. */
const double STAR_RADIUS = 150;

/* Constant controlling how many points the star has. */
const int NUM_STAR_POINTS = 5;

/* Constant defining the mathematical pi */
const double PI = 3.14159265358979323846;

/* Main program */
int main() {
    GWindow window(500, 400);
    double x = window.getWidth() / 2.0;
    double y = window.getHeight() / 2.0;

    /**
     * Draw a series of progressively larger stars centered in the middle of the window.
     */
    double radius = STAR_RADIUS;
    for (int i = 0; i < NUM_STAR_POINTS; i++) {
        /* Compute the angles of the current point and the next point. */
        double theta = (i * 2 * PI / NUM_STAR_POINTS) + PI / 2;
        double nextTheta = ((i + 2) * 2 * PI / NUM_STAR_POINTS) + PI / 2;

        /* Construct a line between those points. */
        GLine* line = new GLine(x + radius * cos(theta), y - radius * sin(theta),
                                x + radius * cos(nextTheta), y - radius * sin(nextTheta));
        /* Update the line color. */
        line->setColor("BLUE");
        /* Display the line. */
        window.add(line);
        // TODO: free memory
    }

    return 0;
}
