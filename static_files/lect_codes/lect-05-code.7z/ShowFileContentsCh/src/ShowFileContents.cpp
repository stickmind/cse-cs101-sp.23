/**
 * File: ShowFileContents.cpp
 * --------------------------
 * This program displays the contents of a file chosen by the user.
 */
#include <fstream>
#include <iostream>
#include <string>
#include "console.h"
#include "simpio.h"
using namespace std;

/* Main program */

int main() {
    // Create an input file stream
    ifstream infile;

    // Get file name and open with file stream
    string filename = getLine("Input file(e.g. Jabberwocky.txt): ");
    infile.open(filename.c_str());

    if (infile.fail()) {
        cout << "Cannot open " << filename << endl;
        return 1;
    }

    // Read chars one bye one and output to console
    // while (true) {
    //     int ch = infile.get();
    //     if (ch == EOF)
    //         break;
    //     cout.put(ch);
    // }
    char ch;
    // while (infile.get(ch)) {
    while ((ch = infile.get()) != EOF) {
        cout.put(ch);
    }

    // Close file stream
    infile.close();
    return 0;
}
