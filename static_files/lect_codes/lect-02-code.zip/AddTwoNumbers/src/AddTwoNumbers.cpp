/*
 * File: AddTwoNumbers.cpp
 * -------------------------
 * This program adds two floating-point numbers and prints their sum.
 */

#include <iostream>
#include "console.h"  // for console
#include "simpio.h"   // for getInteger
using namespace std;

int main() {
  cout << "This program adds two numbers." << endl;
  
  // Read two values from the user.
  int n1 = getInteger("Enter first number: ");
  int n2 = getInteger("Enter second number: ");
  
  // Compute their sum.
  int sum = n1 + n2;
  
  // Print out the summation.
  cout << "The sum is " << sum << endl;
  
  return 0;
}
