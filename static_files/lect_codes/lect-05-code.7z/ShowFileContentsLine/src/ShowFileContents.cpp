/**
 * File: ShowFileContents.cpp
 * --------------------------
 * This program displays the contents of a file chosen by the user.
 */
#include <fstream>
#include <iostream>
#include <string>
#include "console.h"
#include "filelib.h"
#include "simpio.h"
using namespace std;

/* Main program */

int main() {
    // Open text file
    ifstream infile;
    promptUserForFile(infile, "Input file(e.g. Jabberwocky.txt): ");

    // Process text file
    string line;
    while (getline(infile, line)) {
        cout << line << endl;
    }

    // Close text file
    infile.close();

    return 0;
}
