/**
 * File: Swap.cpp
 * --------------
 * This program swaps the values of two integers.
 */

#include <iostream>
#include "console.h"
#include "simpio.h"
using namespace std;

// TODO
void swap(int value1, int value2) {
    int temp = value1;
    value1 = value2;
    value2 = temp;
}

/* Main program */

int main() {
    int value1 = getInteger("Enter your number #1: ");
    int value2 = getInteger("Enter your number #2: ");

    cout << "Swapping..." << endl;
    swap(value1, value2);

    cout << "The value #1 is " << value1 << endl;
    cout << "The value #2 is " << value2 << endl;

    return 0;
}
