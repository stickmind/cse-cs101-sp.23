/**
 * File: HelloWorld.cpp
 * --------------------
 * This file is adapted from the example
 * on page 1 of Kernighan and Ritchie's
 * book The C Programming Language.
 */

#include <iostream>

int main() {
    std::cout << "Hello, World" << std::endl;
    return 0;
}
